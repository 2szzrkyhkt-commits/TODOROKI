各ファイルをGitHubリポジトリのトップ階層へアップロードし、各HTMLの<head>内に以下を追加してください。

<link rel="icon" href="/favicon.svg" type="image/svg+xml">
<link rel="icon" href="/favicon.ico" sizes="any">
<link rel="apple-touch-icon" href="/apple-touch-icon.png">
